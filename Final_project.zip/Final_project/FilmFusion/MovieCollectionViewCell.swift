//
//  MovieCollectionViewCell.swift
//  FilmFusion
//
//  Created by SwarupaJinne on 12/4/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
  
    

    @IBOutlet weak var MovieImageOL: UIImageView!
    
    
    func assignMovies(with Moviee : Movie) {
        MovieImageOL.image = Moviee.image
        
    }
    
}
